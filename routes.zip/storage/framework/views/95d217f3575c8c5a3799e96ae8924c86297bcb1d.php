

<?php $__env->startSection('content'); ?>


<div class="container mt-5">

    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800 py-2">Shipments </h1>
    <a class="btn btn-primary py-2" href="<?php echo e(route('home')); ?>">Go Back</a>
    </div>

    <!-- Content Row -->
    <div class="row pb-5 mb-5 px-3">
        <!-- Begin Page Content -->
        <form method="POST" action="<?php echo e(route('shipmentc.update' , $ships->id)); ?>" >
            <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="form-group">
                    <div class="row">
                        <div class="col-md-6 py-2">
                            <label for="origin" >Origin:</label>
                            <input type="text" name='origin' class="form-control "  id="origin" value="<?php echo e($ships->Origin); ?>">
                        </div>
                        <div class="col-md-6 py-2">
                            <label for="origin" >Desination:</label>
                            <input type="text" name='desination' class="form-control " id="desination" value="<?php echo e($ships->Destination); ?>" >
                        </div>
                    </div>
                </div>
                <div class="consigneebox bg-light p-2 my-3">
                    <h6>
                        Consignee
                    </h6>
                    <?php $__currentLoopData = $consignee; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $consee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                    <?php if($consee->ShipmentID == $ships->id): ?>
                    <div class="form-group">
                        <input type="number" name='conseeid' class="form-control "  id="conseeid" value="<?php echo e($consee->id); ?>" hidden>
                        <div class="row">
                            <div class="col-md-6 py-2">
                                <label for="Name" >Name:</label>
                            
                            <input type="text" name='cName' class="form-control "  id="cName" value="<?php echo e($consee->Name); ?>">
                            </div>
                            <div class="col-md-6 py-2">
                                <label for="cphone" >Phone No:</label>
                            <input type="text" name='cphone' class="form-control "  id="cphone" value="<?php echo e($consee->Phoneno); ?>">
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="row">
                            <div class="col-md-6 py-2">
                                <label for="caddress" >Address:</label>
                                <textarea name="caddress" class="form-control " id="caddress" ><?php echo $consee->Address; ?></textarea>
                            </div>
                            
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="row">
                            <div class="col-md-6 py-2">
                                <label for="ccity" >City:</label>
                            <input type="text" name='ccity' class="form-control "  id="ccity" value="<?php echo e($consee->City); ?>">
                            </div>
                            <div class="col-md-6 py-2">
                                <label for="cCountry" >Country:</label>
                            <input type="text" name='cCountry' class="form-control "  id="cCountry" value="<?php echo e($consee->Country); ?>">
                            </div>
                            <div class="col-md-6 py-2">
                                <label for="czipcode" >Zip/Postal Code:</label>
                            <input type="text" name='czipcode' class="form-control "  id="czipcode" value="<?php echo e($consee->zipcode); ?>">
                            </div>
                        </div>
                    </div>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>



                <div class="consigneebox bg-light p-2 my-3">
                    <h6>
                        Consignor
                    </h6>
                    <?php $__currentLoopData = $consignor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cons): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                    <?php if($cons->ShipmentID == $ships->id): ?>
                    <div class="form-group">
                        <div class="row">
                            <input type="number" name='consid' class="form-control "  id="consid" value="<?php echo e($cons->id); ?>" hidden>
                            <div class="col-md-6 py-2">
                                <label for="Name" >Name:</label>
                            <input type="text" name='DesName' class="form-control "  id="DesName" value="<?php echo e($cons->Name); ?>">
                            </div>
                            <div class="col-md-6 py-2">
                                <label for="pone" >Phone No:</label>
                            <input type="text" name='Desphone' class="form-control "  id="Desphone" value="<?php echo e($cons->Phoneno); ?>">
                            </div>
                            
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="row">
                            <div class="col-md-6 py-2">
                                <label for="origin" >Address:</label>
                                <textarea name="desaddress" class="form-control " id="desaddress" ><?php echo $cons->Address; ?>

                                </textarea>
                            </div>
                            
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="row">
                            <div class="col-md-6 py-2">
                                <label for="Name" >City:</label>
                            <input type="text" name='descity' class="form-control "  id="descity" value="<?php echo e($cons->City); ?>">
                            </div>
                            <div class="col-md-6 py-2">
                                <label for="Name" >Country:</label>
                            <input type="text" name='desCountry' class="form-control "  id="desCountry" value="<?php echo e($cons->Country); ?>">
                            </div>
                            <div class="col-md-6 py-2">
                                <label for="Name" >Zip/Postal Code:</label>
                            <input type="text" name='deszipcode' class="form-control "  id="deszipcode" value="<?php echo e($cons->zipcode); ?>">
                            </div>
                        </div>
                    </div>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <div class="form-group">
                    <div class="row">
                        <div class="col-md-6 py-2">
                            <label for="noofpkgs" >No of Packages:</label>
                            <input type="number" name='Noofpkgs' class="form-control "  id="Noofpkgs" value="<?php echo e($ships->Noofpkgs); ?>" >
                        </div>
                        <div class="col-md-6 py-2">
                            <label for="noofpkgs" >Total weights:</label>
                            <input type="number" name='Totalweight' class="form-control "  id="Totalweight"  value="<?php echo e($ships->Totalweight); ?>">
                        </div>
                        
                        
                    </div>
                </div>
                <div class="heading text-center">
                    <h6>
                        DIMENSIONS OF BOX (CM) 
                    </h6>
                </div>
                <div class="row dimention ">
                    <div class="col-md-6 py-2">
                        <label for="Length" >Length (cm):</label>
                        <input type="number" name='Length' class="form-control "  id="Length"  value="<?php echo e($ships->Length); ?>">
                    </div>
                    <div class="col-md-6 py-2">
                        <label for="Weight" >Weight (cm):</label>
                        <input type="number" name='Weight' class="form-control "  id="Weight"  value="<?php echo e($ships->width); ?>">
                    </div>
                    <div class="col-md-6 py-2">
                        <label for="height" >height (cm):</label>
                        <input type="number" name='height' class="form-control "  id="height"  value="<?php echo e($ships->height); ?>">
                    </div>
                    <div class="col-md-6 py-2">
                        <label for="height" >volweight(kg):</label>
                        <input type="number" name='height' class="form-control "  id="height"  value="<?php echo e($ships->volweight); ?>" disabled>
                    </div>
                </div>


                <div class="form-group">
                    <div class="row">
                        <div class="col-md-6 py-2">
                            <label for="origin" >Description:</label>
                            <textarea name="Description" class="form-control " id="editor" ><?php echo $ships->DescripOfContents; ?></textarea>
                        </div>
                    </div>
                </div>

                <div class="form-group">
                    <div class="row">
                        <?php $__currentLoopData = $tracks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $track): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <?php if($track->ShipmentID == $ships->id): ?>
                        <div class="col-md-6 py-2">
                            <input type="number" name='tackid' class="form-control "  id="tackid" value="<?php echo e($track->id); ?>" hidden>
                            <label for="trackingstatus" >Tracking Status :</label>
                            <select name="trackingstatus" class="custom-select">
                                <option value="<?php echo e($track->Status); ?> " selected><?php echo e($track->Status); ?> </option>
                                <option value="Shipment information received">Shipment information received</option>
                                <option value="Shipment received at Hub">Shipment received at Hub</option>
                                <option value="Shipment left from Hub">Shipment left from Hub</option>
                                <option value="Intransit">Intransit</option>
                                <option value="Out for Delivery">Out for Delivery</option>
                                <option value="Delivery">Delivery</option>
                                <option value="Hold">Hold</option>
                            </select>
                        </div>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-6 py-2">
                            <label for="origin" >Payment Mode :</label>
                            
                            <select name="paymentmode" class="custom-select">
                               
                                <?php if( $ships->Payment_mode): ?>
                                    <option value="1" selected>Online</option>
                                    <option value="0">Cash</option>
                                <?php else: ?> 
                                    <option value="0" selected>Cash</option>
                                    <option value="1">Online</option>
                                <?php endif; ?>
                               
                                
                            </select>
                        </div>
                        <?php $__currentLoopData = $bills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($bill->ShipmentID == $ships->id): ?>
                                <div class="col-md-6 py-2">
                                    <input type="number" name='billid' class="form-control "  id="billid" value="<?php echo e($bill->id); ?>" hidden>
                                    <label for="origin" >Amount :</label>
                                    <input type="number" name='Amount' class="form-control "  id="Amount"  value="<?php echo e($bill->Amount); ?>">

                                    <label for="origin" >Final Amount :</label>
                                    <input type="number" name='totalAmount' class="form-control "  id="totalAmount"  value="<?php echo e($bill->TotalAmount); ?>" disabled>
                                </div>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-6 py-2">
                            <label for="origin" >Packaging Check
                                One Box :</label>
                                <select name="docornot" class="custom-select">
                                    <?php if($ships->docornot ): ?>
                                        <option  value="1" selected>Documents</option>
                                        <option value="0">Non Documents</option> 
                                    <?php else: ?>
                                        <option value="0" selected>Non Documents</option>
                                        <option  value="1" >Documents</option>     
                                    <?php endif; ?>                               
                                </select>
                        </div>
                    </div>
                </div>    
                <div class="btnbox text-center">
            <button type="submit" class="btn btn-primary my-4">Update Now</button>
                
                </div>    
        </form>
          
    </div>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\upwork\resources\views/shipment/edit.blade.php ENDPATH**/ ?>