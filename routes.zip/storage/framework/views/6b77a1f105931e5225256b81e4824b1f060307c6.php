  






  <nav class="navbar navbar-expand navbar-dark bg-dark topbar mb-4 static-top shadow">
    <div class="container">
      <a href="<?php echo e(route('home')); ?>"><h4 class="text-white">Upbox</h4></a>
  
      <!-- Topbar Navbar -->
      <ul class="navbar-nav ml-auto">
  
          <!-- Nav Item - Search Dropdown (Visible Only XS) -->
          <li class="nav-item dropdown no-arrow d-sm-none">
              
              <!-- Dropdown - Messages -->
              <div class="dropdown-menu dropdown-menu-right p-3 shadow animated--grow-in" aria-labelledby="searchDropdown">
                  
              </div>
          </li>
  
          
  
          <div class="topbar-divider d-none d-sm-block"></div>
  
          <!-- Nav Item - User Information -->
          <li class="nav-item dropdown no-arrow">
              <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                  <span class="mr-2 d-none d-lg-inline text-gray-600 small"><?php echo e(Auth::user()->name); ?></span>
                  <img class="img-profile rounded-circle" src="<?php echo e(asset('assets/images/user.png')); ?>" alt='' width="30">
              </a>
              <!-- Dropdown - User Information -->
              <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="userDropdown">
                  
                  
                  <div class="dropdown-divider"></div>
                  <a class="dropdown-item" href="#" href="<?php echo e(route('logout')); ?>"
                  onclick="event.preventDefault();
                                document.getElementById('logout-form').submit();">
                  
                      <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                      <?php echo e(__('Logout')); ?>

                  </a>
                  <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                    <?php echo csrf_field(); ?>
                </form>
              </div>
          </li>
  
      </ul>
    </div>
   

</nav><?php /**PATH C:\wamp64\www\upwork\resources\views/layouts/dashheader.blade.php ENDPATH**/ ?>