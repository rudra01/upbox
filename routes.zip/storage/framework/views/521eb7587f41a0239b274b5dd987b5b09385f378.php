<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta content="" name="description">
    <meta content="" name="keywords">

  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">

    <title>Airway Bill</title>
</head>
<body>
    
    <div class="container"  style="font-size:7px">
        <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <img src="<?php echo e(asset('assets/vectors/Upbox_blue.svg')); ?>" alt="" width="auto" height="50px">

        </div>
        <!-- Page Heading -->
        <div class="d-sm-flex align-items-center justify-content-center " style="font-size:7px">
        
        <div class="barcode text-center" style="font-size:7px">
            <h1 class="h3 mb-0 text-gray-800">Shipments </h1>
            <h6>
                <?php echo e($ships->created_at->toDateString()); ?>

            </h6>
            <h6>
                Tracking No: <?php echo e($ships->barcodeno); ?>

            </h6>
            
            <?php
                $generatorPNG = new Picqer\Barcode\BarcodeGeneratorPNG();
            ?>
            <img src="data:image/png;base64,<?php echo e(base64_encode($generatorPNG->getBarcode('<?php echo $ships->barcodeno; ?>', $generatorPNG::TYPE_CODE_128))); ?>" width="350">
                                
        </div>
        </div>
    
        <!-- Content Row -->
        <div class="row py-5 " style="font-size:7px">
            <div class="col-md-12">
                <div class="box border shadow-none " style="border-color:#41D3EA!important;">
                    <table class="table table-hover ">
                        <tr>
                            <td><strong>Origin: </strong> <?php echo e($ships->Origin); ?></td>
                            <td><strong>Destination: </strong> <?php echo e($ships->Destination); ?></td>
                        </tr>
                    </table>
                </div>
            </div>
            <div class="col-md-6">
                <div class="box border shadow-none" style="border-color:#41D3EA!important;font-size:7px;">
                    <h6 style="font-size:7px; padding: 2px;">
                        CONSIGNOR
                    </h6>
                    <table class="table table-hover ">
                       <?php $__currentLoopData = $consignor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cons): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($cons->ShipmentID == $ships->id): ?>
                                <tbody>
                                <tr>
                                    <td colspan="3"><strong>Name:</strong> <?php echo e($cons->Name); ?></td>
                                </tr>
                                <tr>
                                    <td colspan="3"><strong>Address:</strong> <?php echo e($cons->Address); ?></td>
                                </tr>
                                <tr>
                                    <td><strong>City:</strong> <?php echo e($cons->City); ?></td>
                                    <td><strong>ZipCode:</strong> <?php echo e($cons->zipcode); ?></td>
                                </tr>
                                <tr>
                                    <td><strong>Country:</strong> <?php echo e($cons->Country); ?></td>
                                    <td><strong>Phone No:</strong> <?php echo e($cons->Phoneno); ?></td>
                                </tr>
                                </tbody>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                </div>
            </div>
    
    
            <div class="col-md-6" style="font-size:7px">
                <div class="box border shadow-none " style="border-color:#41D3EA!important;font-size:7px;">
                    <h6 style="font-size:7px; padding: 2px;">
                        CONSIGNEE
                    </h6>
                    <table class="table table-hover ">
                       <?php $__currentLoopData = $consignee; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $conee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($conee->ShipmentID == $ships->id): ?>
                                <tbody>
                                <tr>
                                    <td colspan="3"><strong>Name:</strong> <?php echo e($conee->Name); ?></td>
                                </tr>
                                <tr>
                                    <td colspan="3"><strong>Address:</strong> <?php echo e($conee->Address); ?></td>
                                </tr>
                                <tr>
                                    <td><strong>City:</strong> <?php echo e($conee->City); ?></td>
                                    <td><strong>ZipCode:</strong> <?php echo e($conee->zipcode); ?></td>
                                </tr>
                                <tr>
                                    <td><strong>Country:</strong> <?php echo e($conee->Country); ?></td>
                                    <td><strong>Phone No:</strong> <?php echo e($conee->Phoneno); ?></td>
                                </tr>
                                </tbody>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                </div>
            </div>
    
            <div class="col-md-12" style="font-size:7px">
                <div class="box border shadow-none" style="border-color:#41D3EA!important;">
                    <table class="table table-hover ">
                        <tbody>
                            <tr>
                                <td ><strong> NO. OF PKGS:</strong> <?php echo e($ships->Noofpkgs); ?></td>
                                <td ><strong>  TOTALWEIGHT:</strong> <?php echo e($ships->Totalweight); ?></td>
                                <td ><strong> DIMENSIONS OF BOX(CM):</strong> <br> <?php echo e($ships->Length); ?> x <?php echo e($ships->width); ?> x <?php echo e($ships->height); ?></td>
                                <td ><strong> VOLUMETRIC WEIGHT:</strong> <br> <?php echo e($ships->volweight); ?> KG</td>
                            
                            </tr>
                            <tr>
    
                                <td colspan="4"><strong>DESCRIPTION OFCONTENTS:</strong> <br> <?php echo $ships->DescripOfContents; ?></td>
                                
                            </tr>
                            <tr>
                                <td><strong>PACKAGING CHECK ONE BOX:</strong> <br>
    
                                    <?php if($ships->docornot): ?>
                                       Documents
                                    <?php else: ?>
                                       Non Documents
                                    <?php endif; ?>   
                               </td>
                                <td><strong>Payment Mode :</strong> <br> 
                                    <?php if( $ships->Payment_mode): ?>
                                        Online
                                    <?php else: ?> 
                                        Cash
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php $__currentLoopData = $tracks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $track): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($track->ShipmentID == $ships->id): ?>
                                    <strong>Tracking Status:</strong> <br> <?php echo e($track->Status); ?>

                                    <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </td>
                                <td>
                                    <?php $__currentLoopData = $bills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($bill->ShipmentID == $ships->id): ?>
                                    <strong>Total Amount:</strong> <br> <?php echo e($bill->TotalAmount); ?>

                                    <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </td>
                            </tr>
                        </tbody>
                     </table>
                </div>
            </div>
              
        </div>
       
    </div>
</body>
</html><?php /**PATH C:\wamp64\www\upwork\resources\views/pdf/airwaybill.blade.php ENDPATH**/ ?>