<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Shipment;
use App\Consignee;
use App\Consignor;
use App\Trackshipment;
use App\Billing;
class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        $ships = Shipment::all();
        $consignee = Consignee::all();
        $consignor = Consignor::all();
        $tracks = Trackshipment::all();
        $bills = Billing::all();
        return view('home', compact('ships', 'consignee' , 'consignor' , 'tracks', 'bills'));
    }



    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function shipment(Request $request)
    {
       
        return response()->json([
            'message'   => 'incontroller',
            'class_name'  => 'alert-success',
            'test' => 'success',
            ]);
    }
}
