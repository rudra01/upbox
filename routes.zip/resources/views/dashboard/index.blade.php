

@extends('layouts.dash')

@section('content')


<div class="container-fluid">

    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800">Courses</h1>
    <a href="/course/create" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i class="fas fa-download fa-sm text-white-50"></i> Add Course</a>
    </div>

    <!-- Content Row -->
    <div class="row">
        <!-- Begin Page Content -->
        <div class="container-fluid">

            <!-- Page Heading -->
            {{-- <h1 class="h3 mb-2 text-gray-800">Tables</h1>
            <p class="mb-4">DataTables is a third party plugin that is used to generate the demo table below. For more information about DataTables, please visit the <a target="_blank" href="https://datatables.net">official DataTables documentation</a>.</p>
   --}}
            
            <!-- DataTales Example -->
            <div class="card shadow mb-4">
              <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Courses </h6>
              </div>
              <div class="card-body">
                <div class="table-responsive">
                  <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                      <tr>
                        <th>#</th>
                        <th>Title</th>
                        <th>Category</th>
                        <th>Sub Des</th>
                        {{-- <th>Description</th> --}}
                        <th>Image</th>
                        <th>Price</th>
                        <th>Rating</th>
                        <th>Tags</th>
                        <th>Action</th>
                      </tr>
                    </thead>
                    <tfoot>
                      <tr>
                        <th>#</th>
                        <th>Title</th>
                        <th>Category</th>
                        <th>Sub Des</th>
                        {{-- <th>Description</th> --}}
                        <th>Image</th>
                        <th>Price</th>
                        <th>Rating</th>
                        <th>Tags</th>
                        <th>Action</th>
                      </tr>
                    </tfoot>
                    <tbody id="patnertable">
                        @if (count($cats)> 0)
                          @foreach ($cats as $cat)
                          <tr>
                            <th>{{$cat->id}}</th>
                            <th>{{$cat->title}}</th>
                            <th>
                            @if (count($cataegory)>0)
                              @foreach ($cataegory as $item)
                                  @if ($cat->category == $item->id)
                                    {{$item->name}}
                                  @endif
                              @endforeach
                            @endif
                          </th>
                            <th>{!!$cat->subtitle!!}</th>
                            {{-- <th>{!!$cat->desc!!}</th> --}}
                            <td>
                              <img src={{url('/storage/course_image/'.$cat->img)}} alt="demo"  width="100">
                            </td>
                            <td>{{$cat->rate}}</td>
                            <td>{{$cat->rating}}</td>
                            <td>{{$cat->tag}}</td>

                            <td class="d-flex justify-content-center">
                              <a href="/course/{{$cat->id}}/edit" class="btn btn-primary btn-circle mr-2 " title="Edit"  >
                                  <i class='fas'>&#xf044;</i>
                              </a>
                              <form action="{{ route('course.destroy' , $cat->id ) }}" method="post">
                                  @csrf
                                  @method('DELETE')
                                  <button type="submit" class="btn btn-danger btn-circle" title="Delete">
                                        <i class="fas fa-trash"></i>
                                  </button>
                              </form>
                            </td>
                          </tr>
                          @endforeach
                        @endif
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
  
          </div>
          <!-- /.container-fluid -->
  
    </div>

</div>
@endsection