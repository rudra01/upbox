@extends('layouts.dash')

@section('content')


<div class="container-fluid mt-5">

    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800">Shipments</h1>
    <button class="btn btn-primary" data-toggle="modal" data-target="#CreateShipment">New Shipment</button>
    </div>

    <!-- Content Row -->
    <div class="row">
        <!-- Begin Page Content -->
        <div class="container-fluid">
            
            
        </div>
          <!-- /.container-fluid -->
    </div>

</div>

  

@endsection
