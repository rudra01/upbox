<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class WebpageController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        return view('Homepage');
    }

    public function Track()
    {
        //
        return view('Track');
    }
    public function Contact()
    {
        //
        return view('Contact');
    }

    public function Feature()
    {
        //
        return view('Feature');
    }
    public function RateCalculator()
    {
        //
        return view('RateCalculator');
    }
    
}
