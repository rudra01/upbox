<!DOCTYPE html>
<html lang="en">
<head>
  <title>Upbox</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css" integrity="sha384-lZN37f5QGtY3VHgisS14W3ExzMWZxybE1SJSEsQp9S+oqd12jhcu+A56Ebc1zFSJ" crossorigin="anonymous">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.carousel.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.theme.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link href="<?php echo e(asset('assets/vonder/bootstrap-icons/bootstrap-icons.css')); ?>" rel="stylesheet">
  <link rel="preload" href="<?php echo e(asset('assets/fonts/Outfit-Black.woff2')); ?>" as="font" type="font/woff2" crossorigin>
  <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">

</head>
<body>
<?php echo $__env->make("layouts.nav", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->yieldContent('content'); ?>
  
<footer>
    <div class="container-fluid mt-5 text-center pt-5 " >
        <div class="container">
            <div class="row pb-3">
                <div class="col-sm-3 text-white pb-3">
                    <img src="<?php echo e(asset('assets/images/logos/UPBOX_LOGO_WHITE.png')); ?>" style="height: 50px; width: 150px;">
                </div><br><br>
                <div class="col-sm-3 text-white pt-3 text-left">
                    <p>We don't deliver packages, We deliver promises</p>
                </div>
                <div class="col-sm-3 text-white  text-left">
                    <h5>Office</h5>
                    <p>Prithavi park, Tilak Nagar,<br> New Delhi-110018</p>
                </div>
                
                <div class="col-sm-3 text-white  text-left">
                    <h5>Contacts</h5>
                    <p>info@upbox.co.in</p>
                </div>
            </div>
        
            <div class="row copyrightcolm">
                <div class="col-md-6 py-3" style=" color: white; ">
                    ©2022. all rights reserved.
                </div>
                <div class="col-md-6 socialmedia py-3">
                    <ul>
                        <li>
                            <i class="fa fa-facebook bottomicons"></i>
                        </li>
                        <li>
                            <i class="fa fa-instagram bottomicons"></i>
                        </li>
                        <li>
                            <i class="fa fa-twitter bottomicons"></i>
                        </li>
                    </ul>
                    
                    
                </div>
            </div>

        </div>
    </div>
</footer>


<!-- ======= Moble Footer ======= -->
<div class="container-fluid mobile-footer-bar d-flex w-100">
	<div class="homebar w-100 d-block py-2">
		<a href="<?php echo e(route('homepage')); ?>" class=" d-block w-100 text-center"></i><i class="bi bi-house-fill d-block" style="font-size:24px"></i>
		<span>Home</span>
	  </a> 
	</div>
	<div class="servicebar  w-100 d-block py-2">
	  <a href="<?php echo e(route('Feature')); ?>" class=" d-block w-100 text-center"><i class="bi bi-receipt d-block" style="font-size:24px"></i>
		<span>Features</span>
	  </a>
	</div>
	<div class="newsbar  w-100 d-block py-2">
	  <a href="<?php echo e(route('RateCalculator')); ?>" class=" d-block w-100 text-center"><i class="bi bi-calculator-fill d-block" style="font-size:24px"></i>
		<span> Rate Calculater</span>
	  </a>
	</div>
	<div class="calender w-100 d-block py-2">
		<a href="<?php echo e(route('Track')); ?>" class=" d-block w-100 text-center"><i class="bi bi-send-fill d-block" style="font-size:24px"></i>
		<span>Track</span>
	  </a>
	</div>
  </div>


  <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
  <script type="text/javascript" src="https://code.jquery.com/jquery-1.12.0.min.js"></script>
  <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.carousel.min.js"></script>

  <script>
    $(document).ready(function() {
      $("#testimonial-slider").owlCarousel({
        items: 2,
        itemsDesktop: [1000, 2],
        itemsDesktopSmall: [990, 2],
        itemsTablet: [768, 1],
        pagination: true,
        navigation: false,
        navigationText: ["", ""],
        slideSpeed: 1000,
        autoPlay: true
      });
    });
  </script>


<script>/* Toggle between adding and removing the "responsive" class to topnav when the user clicks on the icon */
	function myFunction() {
	  var x = document.getElementById("myTopnav");
	  if (x.className === "topnav") {
		x.className += " responsive";
	  } else {
		x.className = "topnav";
	  }
	}</script>
</body>

</html><?php /**PATH C:\wamp64\www\upwork\resources\views/layouts/layout.blade.php ENDPATH**/ ?>