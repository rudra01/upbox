

<?php $__env->startSection('content'); ?>
<div class="headbody bg-light p-5 text-center">
    <h2 class="p-5">
        Track Now
    </h2>
</div>
<div class="tackbox my-5 pt-5">
    <div class="container pt-5">
        <div class="row">
            <div class="col-md-12 text-center ">
                <img src="assets/images/tack.svg" alt="" height="150px">
                <div class="my-3">
                    <input type="email" class="form-control" id="trackFormControlInput1" placeholder="Search or Tracking Number">
                    <div class="mt-4 text-center">
                        <button type="submit" class="btn btn-primary mb-3">Track Now</button>
                    </div>
                  </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\upwork\resources\views/Track.blade.php ENDPATH**/ ?>