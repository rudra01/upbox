<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Trackshipment extends Model
{
    //
}
